package month11.day12;

/**
 * ClassName: Task01
 * Description:
 * date: 2021/11/12 9:38
 *
 * @author: Lilin
 * @since JDK 1.8
 */
public class Task01 {
}
